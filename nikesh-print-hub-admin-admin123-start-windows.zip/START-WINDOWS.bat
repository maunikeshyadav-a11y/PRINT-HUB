@echo off
setlocal
title NIKESH PRINT HUB - START WINDOWS
cd /d "%~dp0"

echo ==========================================
echo       NIKESH PRINT HUB - WINDOWS START
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  echo Install Node.js LTS, then run this file again.
  pause
  exit /b 1
)

if not exist "backend\node_modules" (
  echo Installing backend dependencies...
  cd /d "%~dp0backend"
  call npm install
  if errorlevel 1 (
    echo Backend dependency installation failed.
    pause
    exit /b 1
  )
)

if not exist "print-agent\node_modules" (
  echo Installing print-agent dependencies...
  cd /d "%~dp0print-agent"
  call npm install
  if errorlevel 1 (
    echo Print-agent dependency installation failed.
    pause
    exit /b 1
  )
)

echo Starting backend...
start "NIKESH PRINT HUB - Backend" cmd /k "cd /d ""%~dp0backend"" && node server.js"

timeout /t 3 /nobreak >nul

echo Starting Windows Print Agent...
start "NIKESH PRINT HUB - Print Agent" cmd /k "cd /d ""%~dp0print-agent"" && node agent.js"

timeout /t 2 /nobreak >nul

echo.
echo ==========================================
echo Backend: http://localhost:5000
echo Admin:   http://localhost:5000/admin-login.html
echo Login:   admin / admin123
echo ==========================================
echo.
echo Backend and Print Agent are running in separate windows.
echo Do not close those windows while using the system.
echo.
pause
endlocal
